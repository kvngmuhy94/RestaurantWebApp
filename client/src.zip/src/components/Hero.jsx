import React from 'react'

const Hero = () => {
  return (
    <div className='flex items-center justify-between py-3 md:py-5 md:block bg-sky-500'>
       <div className='w-full h-full py-2 px-4'>Hero</div> 
    </div>
  )
}

export default Hero