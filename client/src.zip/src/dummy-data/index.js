export { default as casio1a } from "./casio1a.jpg";
export { default as casio1b } from "./casio1b.jpg";
export { default as casio1c } from "./casio1c.jpg";
export { default as casio2a } from "./casio2a.jpg";
export { default as casio2b } from "./casio2b.jpg";
export { default as casio3 } from "./casio3.jpg";
export { default as casio4 } from "./casio4.jpg";
export { default as gshock1 } from "./gshock1.jpg";
export { default as gshock2 } from "./gshock2.jpg";
export { default as gshock3 } from "./gshock3.jpg";
export { default as hublot1 } from "./hublot1.jpg";
export { default as hublot2 } from "./hublot2.jpg";
export { default as hublot3 } from "./hublot3.jpg";
export { default as hublot4 } from "./hublot4.jpg";
export { default as hublot5a } from "./hublot5a.jpg";
export { default as hublot5b } from "./hublot5b.jpg";
export { default as leatherWatch1a } from "./leather-watch1a.jpg";
export { default as leatherWatch1b } from "./leather-watch1b.jpg";
export { default as leatherWatch1c } from "./leather-watch1c.jpg";
export { default as leatherWatch2 } from "./leather-watch2.jpg";
export { default as leatherWatch3 } from "./leather-watch3.jpg";
export { default as watchgem } from "./watchgem.jpg";
export { default as shoe1 } from "./shoe1.jpg";
export { default as shoe2a } from "./shoe2a.jpg";
export { default as shoe2b } from "./shoe2b.jpg";
export { default as shoe2c } from "./shoe2c.jpg";
export { default as shoe3a } from "./shoe3a.jpg";
export { default as shoe3b } from "./shoe3b.jpg";
export { default as shoe4 } from "./shoe4.jpg";
export { default as shoe5 } from "./shoe5.jpg";
export { default as shoe6 } from "./shoe6.jpg";
export { default as shoe7 } from "./shoe7.jpg";
export { default as shoe8 } from "./shoe8.jpg";
export { default as shoe9 } from "./shoe9.jpg";
export { default as nike1 } from "./nike1.jpg";

export { default as shoeLogo } from "./shoe-logo.jpg";
export { default as watchLogo } from "./watch-logo.jpg";
export { default as companyLogo3 } from "./company-logo3.jpg";




