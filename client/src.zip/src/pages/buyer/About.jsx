
const About = () => {
  return (
    <section classNam="bg-slate-200 flex flex-col items-center w-screen h-screen">
      <h1>About Us</h1>
      <div>
        <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nemo non, cum perspiciatis suscipit autem dolor dolores. Consectetur officia doloribus corporis unde rerum excepturi, id quaerat iusto nisi earum dolor dignissimos assumenda tenetur facilis ipsam, quasi itaque quod quae eius? Eos!
        </p>
      </div>
    </section>
  )
}

export default About